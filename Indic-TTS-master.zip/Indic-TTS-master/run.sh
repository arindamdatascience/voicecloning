CUDA_VISIBLE_DEVICES=2 sh configs/train_fastpitch.sh
